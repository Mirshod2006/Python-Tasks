text=input("Enter some text:")
print(*text,sep='<>')