text ="hello everybidy Ima wrtining tio debate with my brother and bro things that i cannot go over him and cannot write so quick as him so i"
count =0
for i in range(0,len(text)):
    if text[i]==' ':
        count+=1
print(len(text)-count)