a=int()
a=235342
b=float()
b=9385.09453
c=bool()
c=False
d=str()
d="""
Some text 
is being written 
in multiple lines!
"""