print("Hello my Brothers:")
print("Please, target the bomb-side")
print("Hello My Dear",123.42,435,True,False,sep='...',end='The end')
a =23
b = 41.452
c=True
d = 'Foundation'
print("a=",a,"b=",b,"c=",c,"d=",d)
print("a={2} b={1} c={0} d={3}".format(a,b,c,d))
print(f"a={a} b={b} c={c} d={d}")