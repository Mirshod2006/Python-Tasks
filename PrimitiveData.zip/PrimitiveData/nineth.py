text=input("Enter text:")
n=int(input("Enter iteration num:"))
print(text[n]*n)
