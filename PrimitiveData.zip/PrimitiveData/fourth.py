text = input("Enter anything:")
print(text*100)

