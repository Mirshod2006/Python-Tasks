text=input("Enter text:")
index=int(input("Enter index:"))
print(text[index])