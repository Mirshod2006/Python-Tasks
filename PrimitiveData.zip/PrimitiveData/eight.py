text=input("Enter text:")
start=int(input("Enter start:"))
end=int(input("Enter end:"))
print(text[start:end])