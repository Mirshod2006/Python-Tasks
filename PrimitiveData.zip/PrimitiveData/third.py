name = input("Enter your name:")
surname= input("Enter your surname:")
age = input("Enter your age:")
exam_score = input("Enter your exam score:")
print(f"""
        Name : {name},
        Surname : {surname},
        Age : {age},
        Exam Score : {exam_score}
""")