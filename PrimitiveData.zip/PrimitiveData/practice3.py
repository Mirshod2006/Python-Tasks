text="Salom ukam!"
print(*text,sep='+')
print(text*5)
print(text[0],text[1],text[2],text[3],text[4])
# [start:finish:step]
print(text[0:5:1])
print(text[0:len(text):2])
print(text[5:])
print(text[:5])
print(text[5:8])
print(text[::])
print(text[::-1])