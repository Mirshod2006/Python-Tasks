text1=input("Enter first text:")
text2=input("Enter first text:")
text3=input("Enter first text:")
print(
f"""{text1}
{text2}
{text3}""")