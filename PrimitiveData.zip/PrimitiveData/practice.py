num = int() # we created empty integer
print(num,type(num))
num  = 10
print(num,type(num))
# type --- variable defines the type of the variable
num = 3.24
print(num,type(num))
b = float() # we created empty float
print(b,type(b))
c=bool()
print(c,type(c))
c=True
print(c,type(c))
c=20
print(c,type(c))
word = "Nice!"
print(word,type(word))
word=43453413
print(word,type(word))
text = """Hello Python,
I am Machine Learning Engineer,
And I am Full-Stack developer!
"""
print(text,type(text))
print(text)