number = int(input("Enter number:"))
if number%4==0 and number%5!=0:
    print(True)
else:
    print(False)