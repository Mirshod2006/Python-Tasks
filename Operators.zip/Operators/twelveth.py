text = input("Enter text:")
symbol = input("Enter symbol:")
if symbol in text:
    print(True)
else:
    print(False)