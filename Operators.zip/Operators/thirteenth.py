guests=int(input("Enter number of guests:"))
if guests%2==0:
    print(guests/2)
else:
    print(guests)