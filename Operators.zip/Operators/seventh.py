figure={0,1,2,3,4,5,6,7,8,9}
number = int(input("Enter number:"))
if number in figure:
    print("Number is in the figure")
else:
    print("Number is not in the figure")