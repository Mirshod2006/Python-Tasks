number = int(input("Enter number:"))
if number % 2 == 0:
    print(number*2)
else:
    print(number-2)