num = int(input("Enter number:"))
check = True
if num % 7==0:
    print("Number is divisible by 7")
else:
    check=False
    print("Number is not divisible by 7")
print(check)