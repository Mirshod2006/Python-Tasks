num = int(input("Enter number:"))
if num % 2==0:
    print("Number is even")
else:
    print("Number is odd")

if num >0:
    print("Number is positive")
elif num==0:
    print("Number equals to zero")
else:
    print("Number is negative")