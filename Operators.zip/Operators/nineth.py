number = input("Enter number:")
if number[0]=='-':
    print(len(number)-1)
else:
    print(len(number))
