num = int(input("Enter numbers:"))
mul = 1
for i in range(1,num+1):
    mul *=i
print(mul)