square = lambda x : x**2
ls=[1,2,3,4,5,6,7,8,9,10]
squareLs=[]
for i in ls:
    squareLs.append(square(i))
print(squareLs)