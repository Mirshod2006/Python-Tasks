import random as r
import colorama as c
print(c.Style.BRIGHT)
print(c.Fore.BLACK,c.Back.CYAN)
print("Something I liked it!")
print("I do not know why It is being happening")
print(c.Style.RESET_ALL,"Now, Print Some Text")